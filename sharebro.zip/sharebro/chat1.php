<html>
<head>
<meta http-equiv="refresh" content="25"/>
</head>
<body>
<?php
$s=file_get_contents('chat.txt');
print ($s);
$s="";
?>
<form action="chat1.php" method="post">
send some thing<br>
<textarea name="comments" cols="30" rows="5"></textarea>
<input type="submit" name="submit" value=" Double click to send"/>
</form>

<?php
{
if(isset($_POST['comments']))
{$comments=$_POST['comments'];
if(trim($comments)!="")
file_put_contents('chat.txt',"<br>1 says -".$comments,FILE_APPEND);
}}
?>
</body>
</html>
