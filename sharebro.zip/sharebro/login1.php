<html>
<body>
<?php
/*$a="ayush";
$b="piyush";*/



if(isset($_POST['username']))
{
$username=$_POST['username'];
$password=$_POST['password'];
if(file_exists("$username.txt")){
$a=file_get_contents("$username.txt");
$ai=file_get_contents("$username.1.txt");
if($username==$a)
{/*$ai=file_get_contents('ayush.txt');*/
if($password==$ai)
print("sharebro welcomes you.Redirecting please wait"."<meta http-equiv=refresh content=3;url=sharebro.html />");
else print("wrong username or password");
}}
/*if($username==$b)
{$b2=file_get_contents('piyush.txt');
if($password==$b2)
print("sharebro welcomes you. <a href=sharebro.html>click here</a>");*/
else print("wrong username or password"."<meta http-equiv=refresh content=3;url=login.php />");
}

else
print("you are an intruder");
?>
</body>
</html>