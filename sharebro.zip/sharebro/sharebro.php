<html>
<head>
<title>
<?php $username=$_POST['username'];
print $username;
?>
</title>
</head>
<body>
<br><br>
<p align="center"><img src="logo1.jpg"></p><tb><tb>
<?php 
if(isset($_POST['username']))
{
$username=$_POST['username'];
$password=$_POST['password'];
if(file_exists("$username.txt")){
$a=file_get_contents("$username.txt");
$ai=file_get_contents("$username.1.txt");
if($username==$a)
{
if($password==$ai)
print ("welcome <form action=chatsignup.php method=post><input type=hidden name=username value=$username /><button type=submit>$username</button></form></a><tb><tb><tb><tb><tb><font align=right>enjoy our messenger <a href=chatsignup.php>SHARE MSN</a></font> <br><br><br><br><br><br><br><br><br>
<p align=center><font size=6 color=ff0000><b><i>Welcome to  hostel d movie portal</b></i></font><br>
</p><form action=newsfeed.php method=post><input type=hidden name=username value=$username /><button type=submit>newsfeed</button></form>
<a href=bollywood.html>
<img src=bollywood.png align=left></a>
<a href=hollywood.html>
<img src=hollywood.png align=right></a>
<p align=center><a href=ebooks.html><img src=ebook.png align=center></a></p>
</p>");
else print("wrong username or password <meta http-equiv=refresh content=3;url=login.php />");
}}
else print("wrong username or password ");
}

else
print("you are an intruder <meta http-equiv=refresh content=3;url=login.php />");


?>
<a href="login.php"><button value="logout" align="center">logout</button></a>
</body>
</html>