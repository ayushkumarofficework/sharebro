<html>
<title>
<?php $username=$_POST['username'];
print $username;
?>
</title>
</head>
<body>
<br><br>
<p align="center"><img src="logo1.jpg"></p><tb><tb>
<?php $username=$_POST['username'];
$a=file_get_contents("sharemsnlist.php");
print ("welcome $username to our chatting potal<br><br><form action=sharemsn1.php method=post><input type=hidden name=username value=$username /><br>$a<br></form>");
?>

</body>
</html>