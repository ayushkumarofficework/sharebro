<html>
<body>
<?php 
$username=$_POST['username'];
$password=$_POST['password'];
if(!file_exists("$username.txt"))
{
$a=fopen("$username.txt","w");
$b=fopen("$username.1.txt","w");
file_put_contents("$username.txt",$username);
file_put_contents("$username.1.txt",$password);

fclose($a);
fclose($b);
print("you are successfully signed in"."<meta http-equiv=refresh content=3;url=sharebro.html />"); }
else
print("username already exists "."<meta http-equiv=refresh content=3;url=signin.php />");
?>
</body>
</html>