<html>
<title>

</title>
<body>
<?php 
$username=$_POST['username'];
$username1=$_POST['username1'];
if(!file_exists("$username.$username1.txt")){
$a=fopen("$username.$username1.txt","w");
fclose($a);
$c=file_get_contents("$username.$username1.txt");}
print $c;
?>
<form action="sharemsn1.php" method="post">
<input type="hidden" name="username" value="<?php print $_POST['username']; ?>" />
<input type="hidden" name="username1" value="<?php print $_POST['username1']; ?>" />
send some thing<br>
<textarea name="comments" cols="30" rows="5"></textarea>
<input type="submit" name="submit" value="double click here"/>
</form>
<?php
{$username=$_POST['username'];
$username1=$_POST['username1'];
if(isset($_POST['comments']))
{$comments=$_POST['comments'];
if(trim($comments)!="")
file_put_contents("$username.$username1.txt","<br>$username says- ".$comments,FILE_APPEND);
$a=file_get_contents("$username.$username1.txt");
file_put_contents("$username1.$username.txt",$a);
}}
?>
</body>
</html>
