<?php 
//$db=new mysqli('127.0.0.1','root','','ayush');
?>
<html>
<title>
<?php $username=$_POST['username'];
print("$username");
?>
</title>
<body>
<?php 
if(isset($_POST['username'])){
$username=$_POST['username'];
$password=$_POST['password'];
if(!file_exists("$username.txt"))
{
$a=fopen("$username.txt","w");
$b=fopen("$username.1.txt","w");
$c=fopen("sharemsnlist.txt","w");
file_put_contents("$username.txt",$username);
file_put_contents("$username.1.txt",$password);
file_put_contents("sharemsnlist.php","<input type=hidden name=username1 value=$username /><button type=submit>$username</button>",FILE_APPEND);
fclose($a);
fclose($b);
fclose($c);
print("welcome $username"."<meta http-equiv=refresh content=3;url=login.php />"); }
else
print("username already exists "."<meta http-equiv=refresh content=3;url=signin.php />");}
?>
<br><br>
<p align="center"><img src="logo1.jpg"></p><tb><tb>
<br><br><br><br><br><br><br><br><br>
<face align="center">thanks for registering to sharebro</face> 
</p>
</body>
</html>