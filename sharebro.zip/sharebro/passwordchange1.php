<html>
<body>
<?php
if(isset($_POST['username']))
$username=$_POST['username'];
$password=$_POST['password'];
if($username==file_get_contents("$username.txt"))
{/*$a=file_get_contents('ayush.txt');*/
/*while(!feof($a))
{$a1=fgetc($a);*/
if($password==file_get_contents("$username.1.txt"))
print("you r authorised to change password");
else
print("you r not authorised"."<meta http-equiv=refresh content=3;url=passwordchange.php />");
}
?>
<form action="changepassword.php" method="post">
username
<input type="text" name="username" value="<?php print $_POST['username']; ?>"/>
new password
<input type="password" name="password"/>
retype your password
<input type="password" name="password1"/>
<input type="submit" name="submit"/>
</form>
</body>
</html>