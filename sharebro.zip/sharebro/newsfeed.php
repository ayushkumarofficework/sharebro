<html>
<title>
<?php print ($_POST['username']); ?>
</title>
<body>
<form align="center" action="newsfeed.php" method="post">
want to share something using sharebro<br>
<textarea name="post" cols="30" rows="5"></textarea>
<input type="hidden" name="username" value="<?php print($_POST['username']); ?>" />
<input type="submit" name="submit" value="double click to share" />
</form>
<?php 
if(isset($_POST['post']))
{
 $a=$_POST['post'];
 $c=$_POST['username'];
 if(trim($a)!=""){
 $col=array("#2e20ed","#31ef12","#f6d209","#929ef4","#23e989","#ecbc49");
 $ran=array_rand($col,1);
 $rand=$col[$ran];
 $b=file_get_contents('newsfeed.txt');
 $e="<p><ul><font color=$rand>$a</font></ul></p><p>$b</p>";
 $f="<b><p>$c</p></b>$e";
 file_put_contents("newsfeed.txt",$f);}}
 $d=file_get_contents('newsfeed.txt');
 print $d;
 ?>
</body>