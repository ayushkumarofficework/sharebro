<html>
<body>
<?php
if(isset($_POST['password']))
{$username=$_POST['username'];
$password=$_POST['password'];
$password1=$_POST['password1'];
if($password==$password1)
{if($username==file_get_contents("$username.txt"))
{
file_put_contents("$username.1.txt",$password);
print("good to see you chhanging password"."<meta http-equiv=refresh content=3;url=login.php />");}
/*if($username=="piyush")
{file_put_contents('piyush.txt',$password);
print("sharebro welcomes you"."<a href=sharebro.html> <br>click here to enjoy<br></a>");}*/}
else
print ("wrong entry");
}?>
</body>
</html>
