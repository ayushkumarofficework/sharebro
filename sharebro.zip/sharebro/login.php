<html>
<style type="text/css">
div{}
.1{color:"#d9ead9";}
</style>
<body><br><br>
<p align="center"><img src="logo1.jpg"></p><br><br><br><br><br><br><br><br><br>
<p align="center"><font size=6 color="ff0000"><b><i>Welcome to  hostel d movie portal</b></i></font><br></p>
<div class="1" align="center"><font color="#0505fc">already a member log in here<br><br></font>
<form action="sharebro.php" method="post">
<font color=#2108dd>username</font> 
<input type="text" name="username"/>
password
<input type="password" name="password"/>
<input type="submit" name="login" value="login"/></div>
</form>
<div align="center"><form action="passwordchange.php" method="post">
<input type="submit" name="changepassword" value="change password"/>
</form></div>
<p align="center"><a href=signin.php><button>sign in here</button></a></p>

</body>
</html>
 