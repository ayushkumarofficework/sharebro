<html>
<body>
<form method="post" action="passwordchange1.php">
username
<input type="text" name="username"/>
old password
<input type="password" name="password"/>
<input type="submit" name="submit"/>
</form></*?php
if(isset(_POST['username']))
$username=_POST['username'];
$password=_POST['password'];
if($username=="ayush")
{$a=fopen("ayush.txt","r");
$a1=fgetc($a);
if($password==$a1)
print("you r authorised to change password");
}
?*/>
</body>
</html>

