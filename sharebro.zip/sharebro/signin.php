<html>
<body><br><br>
<p align="center"><img src="logo1.jpg"></p><br><br><br><br><br><br><br><br><br>
<p align="center"><font size=6 color="ff0000"><b><i>Welcome to  hostel d movie portal</b></i></font><br></p>
<form action="wallcreator.php" method="post">
<p align="center">Username of ur choice</p>
<p align="center"><input type="text" name="username"/></p>
<p align="center">Password</p>
<p align="center"><input type="password" name="password" align="center"/></p>
<p align="center"><input type="submit" name="submit" value="sign up"/></p>
<?php
/* 
if(isset($_POST['username'])){
$username=$_POST['username'];
$password=$_POST['password'];
if(!file_exists("$username.txt"))
{
$a=fopen("$username.txt","w");
$b=fopen("$username.1.txt","w");
file_put_contents("$username.txt",$username);
file_put_contents("$username.1.txt",$password);

fclose($a);
fclose($b);
print("you are successfully signed in"."<!meta http-equiv=refresh content=3;url=sharebro.php />"); }
else
print("username already exists "."<!meta http-equiv=refresh content=3;url=signin.php />");}
*/
?></form>
</body>
</html>

